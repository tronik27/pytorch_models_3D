"""
Special development kit library
"""
