# Pytorch models 3D


Python library with 3D Neural Networks based on PyTorch.
